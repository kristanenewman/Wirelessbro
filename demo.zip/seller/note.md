# 商家端问题

## 创建page页面

文件: `Wirelessbro/seller/product/create_page.html`

整个页面分为两部分
1. 页面整体信息
 页面整体信息包括三部分：
	- 分类
	- 页面的title
	- 页面的简要介绍（方便用户查找页面原型）
2. 该页面显示的产品相关描述条目模板，该模板用于生成excel表的column

## 产品管理页面
** Ready **
1. 新添加的商品
2. 主动下架商品
3. 审核中的商品

** Selling **
1. 正在销售的商品

** Reject **
1. 未通过平台审核的商品

** withdraw **  
1. 由于销量等原因，平台给予下架的商品
